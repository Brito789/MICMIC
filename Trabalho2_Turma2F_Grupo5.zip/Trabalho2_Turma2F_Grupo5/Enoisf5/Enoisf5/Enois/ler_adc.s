
/*
 * ler_adc.s
 *
 * Created: 09/01/2026 10:20:00
 *  Author: DEE
 */ 
 #include <avr/io.h>
 #define _SRR_OFFSET 0

 .global ler_adc
 .extern leituraAD

 #define somaH r20
 #define somaL r21
 #define contador

 ler_adc:

 PUSH r18
 PUSH r19

 LDI r18, 4
 CLR r24
 CLR r25
 clr r1

 Inic_leitura:

  LDS r19, ADCSRA
  ORI r19, (1 << ADSC)
  STS ADCSRA, r19 

 Conversao:

  LDS r19, ADCSRA
  SBRC r19, ADSC
  RJMP Conversao

  LDS r19, ADCH 

  ADD r24, r19 
  ADC r25, r1 

  DEC r18
  BRNE Inic_leitura 

  LSR r25         
  ROR r24

  LSR r25
  ROR r24

 sts leituraAD, r24
 POP r19
 POP r18

 RET