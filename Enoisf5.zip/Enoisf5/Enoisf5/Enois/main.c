/*
 * Enois.c
 *
 * Created: 09/01/2026 10:18:21
 * Author : DEE
 */ 

#include <avr/interrupt.h>
#include <stdio.h>
#include <stdlib.h>


char buffer[50];
volatile unsigned char cont_botoes;
const unsigned char tabela[] = {0XC0, 0XF9, 0XA4, 0XB0, 0X99, 0X92, 0x82, 0XF8, 0x80, 0x90, 0xFF, 0xBF, 0x88, 0xC1};
unsigned char vect_display[4] = {10, 10, 10, 10};
unsigned char p_display = 0;
unsigned char pwm = 0;
signed char sentido = 1;
volatile unsigned char flag_Rx, caracter;
unsigned char modo_funcionamento = 0;

volatile unsigned int t1_stamp = 0, t2_stamp = 0;
volatile unsigned int cont_ovr = 0, t1_ovr = 0;
volatile unsigned char flag_rpm_pronto = 0;
volatile unsigned long rpm = 0;
volatile unsigned long somar_rpm = 0;

void inicio(void)
{
	DDRC = 0xFF;
	PORTC = 0xFF;
	DDRA = 0b11000000;
	PORTA = 0b00111111;
	DDRB = 0b11100000;
	PORTB = 0b00100000;
	DDRD=0b00000000;

	OCR0 = 77;
	TCCR0 = 0b00001111;
	TIMSK = 0b00000010;

	OCR2 = 0;
	TCCR2 = 0B01100011;

	UBRR1H=0;
	UBRR1L=103;
	UCSR1A=0b00000000;
	UCSR1B=0b10011000;
	UCSR1C=0b00001110;

	ADMUX=0b00100001;  
	ADCSRA=0b10000111; 
	DDRF=0b00000000;

	TCCR1A=0b00000000;
	TCCR1B=0b11000001;
	TCCR1C=0b00000000;
	TIMSK=0b00100110; // n sei se é para mudar o de lá de cima 

	sei();
}

void display(void)
{
	PORTA = p_display << 6;
	PORTC = tabela[vect_display[p_display]];
	p_display++;
	if(p_display == 4)
	p_display = 0;
}

ISR(TIMER0_COMP_vect)
{
	display();
	cont_botoes--;
}

ISR(USART1_RX_vect)
{
	caracter=UDR1;
	flag_Rx=1;
}

ISR(TIMER1_CAPT_vect){
	t2_stamp = t1_stamp;
	t1_stamp = ICR1;       // Guarda o valor capturado do Timer1
	t1_ovr = cont_ovr;     // Guarda quantos overflows ocorreram entre impulsos
	cont_ovr = 0;          // Faz reset ao contador de overflows
	flag_rpm_pronto = 1;   // Sinaliza ao main que pode calcular
}

ISR(TIMER1_OVF_vect){
	cont_ovr++;
	if (cont_ovr > 50) { // Valor MAX para considerar o motor parado
		t1_stamp = 0;
		t1_ovr = 0;
		cont_ovr = 0;
		flag_rpm_pronto = 1;
	}
}

void enviar_Buffer(void)
{
	unsigned char i=0;
	while(buffer[i]!=0)
	{
		while(!(UCSR1A & (1<<UDRE1)));
		UDR1=buffer[i];
		i++;
	}
}


void processar_display(void)
{

	
	if(sentido == -1)
	vect_display[1] = 11;
	else
	vect_display[1] = 10;
	
	if(pwm == 100)
	{
		vect_display[2] = 9;
		vect_display[3] = 9;
	}
	else
	{
		vect_display[2] = pwm / 10;
		vect_display[3] = pwm % 10;
	}
}

void processar_sw(void)
{
	if((PINA & 0b00000001) == 0)
	{
		cont_botoes=1;
		while(cont_botoes!=0);
		if((PINA & 0b00000001) == 0)
		{
			if(pwm+5<=100)
			pwm = pwm + 5;
			while((PINA & 0b00000001) == 0);
		}
	}
	
	if((PINA & 0b00000010) == 0)
	{
		cont_botoes=1;
		while(cont_botoes!=0);
		if((PINA & 0b00000010) == 0)
		{
			if(pwm-5>=0)
			pwm = pwm - 5;
			while((PINA & 0b00000010) == 0);
		}
	}
	
	if((PINA & 0b00000100) == 0)
	{
		pwm = 25;
	}
	
	if((PINA & 0b00001000) == 0)
	{
		pwm = 50;
	}
	
	if((PINA & 0b00010000) == 0)
	{
		cont_botoes=1;
		while(cont_botoes!=0);
		if((PINA & 0b00010000) == 0)
		{
			sentido=-sentido;
			OCR2=0;
			cont_botoes=50;
			while(cont_botoes!=0);
			if(sentido == 1)
			PORTB = (PORTB & 0b10011111) | 0b00100000;
			else
			PORTB = (PORTB & 0b10011111) | 0b01000000;
		}
		
		
		while((PINA & 0b00010000) == 0);
	}
	
	if((PINA & 0b00100000) == 0)
	{
		pwm = 0;
	}
	
	OCR2 = (pwm * 255) / 100;
}

void processar_rx(void)
{
	switch(caracter)
	{
		case'p':
		case'P':
		pwm=0;
		sprintf(buffer,"Motor parado \n\r");
		enviar_Buffer();
		break;
		
		case 'I':
		case 'i':
		sentido=-sentido;
		OCR2=0;
		cont_botoes=50;
		while(cont_botoes!=0);
		if(sentido == 1)
		PORTB = (PORTB & 0b10011111) | 0b00100000;
		else
		PORTB = (PORTB & 0b10011111) | 0b01000000;
		break;
		
		case '1':
		pwm = 25;
		sprintf(buffer,"Velocidade definida para 25 \n\r");
		enviar_Buffer();
		break;
		
		case '2':
		pwm=50;
		sprintf(buffer,"Velocidade definida para 50 \n\r");
		enviar_Buffer();
		break;
		
		case '+':
		if(pwm+5<=100)
		pwm = pwm + 5;
		sprintf(buffer,"Velocidade aumentada para %d%% \n\r", pwm);
		enviar_Buffer();
		break;
		
		case '-':
		if(pwm-5>=0)
		pwm = pwm - 5;
		sprintf(buffer,"Velocidade diminuida para %d%% \n\r", pwm);
		enviar_Buffer();
		break;
		
		case 'b':
		case 'B':
		sprintf(buffer, "Velocidade atual:%d%% \n\r", pwm);
		enviar_Buffer();
		break;
		
	}
	OCR2 = (pwm * 255) / 100;

}

int ler_ADC(void)						
{
	unsigned char lerH;
	
	ADCSRA |= (1 << ADSC);
	
	while ((ADCSRA & (1 << ADSC)) != 0);

	lerH = ADCH;
	
	return lerH;
}
void processar_adc(void)       			 
{
	unsigned int soma = 0;
	
	for(int i = 0; i < 4; i++)
	{
		soma += ler_ADC();
		cont_botoes=50;
	}
	
	if((PINA & 0b00010000) == 0)
	{
		cont_botoes=1;
		while(cont_botoes!=0);
		if((PINA & 0b00010000) == 0)
		{
			sentido=-sentido;
			OCR2=0;
			cont_botoes=50;
			while(cont_botoes!=0);
			if(sentido == 1)
			PORTB = (PORTB & 0b10011111) | 0b00100000;
			else
			PORTB = (PORTB & 0b10011111) | 0b01000000;
		}
	}
	OCR2 = soma/4;
	pwm= (OCR2 * 100)/ 255; 
}

void processar_rpm(void)
{
	if (flag_rpm_pronto) {
		flag_rpm_pronto = 0;
		if (t1_stamp == 0) 
		{
			rpm = 0;
		} else 
		{
			// Delta de ticks considerando os overflows
			long delta_ticks = ((long)t1_ovr * 65536) + t1_stamp - t2_stamp;
			//long delta_ticks = t2_stamp-t1_stamp;
			if (delta_ticks > 0) 
			{
				// RPM = 60 * (f_timer / delta_ticks) / impulsos_por_volta
				// Para Prescaler 64: f_timer = 16MHz / 64 = 250.000 Hz
				// Ttick = 1/250.000 = 0,000004
				//Tpulse = delta_tick * Ttick
				//fpulse = 1/Tpulse = 1/(delta_tick * 0,000004)
				//RPM = 60*((fpulse)/2) = 60* ((1/(delta_tick * 0,000004))/2)
				// RPM = (60 * 250000) / (delta_ticks * 2) = 7.500.000 / delta_ticks
				//rpm = 60/ ((250000*(delta_ticks))/2);
				rpm = 7500000/ (delta_ticks);
					
					
			}
		}
	}
}

int main(void)
{
	inicio();
	while(1)
	{
		processar_display();
		if(flag_Rx==1 &&(caracter=='d' || caracter=='D'))
		{
			
			modo_funcionamento=0;
			sprintf(buffer, "Modo Digital \n\r");
			enviar_Buffer();
			vect_display[0]=0;
			flag_Rx=0;
		}
		if(flag_Rx==1 &&(caracter=='s' || caracter=='S'))
		{
			modo_funcionamento=1;
			sprintf(buffer, "Modo Switch \n\r");
			enviar_Buffer();
			vect_display[0]=5;
			flag_Rx=0;
		}
		if(flag_Rx==1 &&(caracter=='a' || caracter=='A'))           
		{
			modo_funcionamento=2;
			sprintf(buffer, "Modo Analogico \n\r");
			enviar_Buffer();
			vect_display[0]=12;
			flag_Rx=0;
		}
		if(flag_Rx==1 &&(caracter=='v' || caracter=='V'))
		{
			modo_funcionamento=3;
			sprintf(buffer, "Modo Velocidade \n\r");
			enviar_Buffer();
			vect_display[0]=13;
			flag_Rx=0;
		}
		if(modo_funcionamento==0 && flag_Rx ==1)
		{
			processar_rx();
			flag_Rx = 0;
		}
		if(modo_funcionamento==1)
		{
			processar_sw();
		}
		if(modo_funcionamento==2)               
		{
			processar_adc();
		}
		if(modo_funcionamento==3)
		{
			processar_rpm();
		}
	}

}
